size = int(input("How big would you like the triangle "))
for a in range(0, size + 1):
    print("*" * a)
    a += 1